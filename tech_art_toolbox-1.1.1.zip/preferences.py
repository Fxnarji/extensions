import bpy  # type: ignore
from .helper import get_operator


class Sample_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text = "Made By:")
        box.label(text = "Fxnarji")
        box.label(text = "Zophiekat")


