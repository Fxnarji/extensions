# i like to put values i need in multiple places here so i can change them in one place
import bpy  # type: ignore
import os
import tomllib
from mathutils import Matrix, Vector    # type: ignore
from bpy.types import Object  # type: ignore
from typing import Optional
# has to be all lowercase
bl_id_prefix = "my_addon"

class AddonProperties:
    module_name = __package__
    panel_category = "SamplePanel"


def get_manifest():
    toml_path = os.path.join(os.path.dirname(__file__), "blender_manifest.toml")
    with open(toml_path, "rb") as f:
        manifest = tomllib.load(f)
    return manifest


def get_preferences():
    # No context needed, directly get addon preferences by package name
    addon_prefs = bpy.context.preferences.addons.get(__package__).preferences
    return addon_prefs

def get_operator(name):
    return bl_id_prefix + "." + name

def add_armature(name, context, select = True):
    armature = bpy.data.armatures.new(name)

    armature_obj = bpy.data.objects.new(name, armature)

    context.collection.objects.link(armature_obj)
    if select:
        armature_obj.select_set(True)
    return armature_obj

def flip_bone(bone):
    old_head = bone.head.copy()
    bone.head = bone.tail
    bone.tail = old_head

def get_selected_vertices_from_mesh(mesh) -> list:

    selected = []
    for vertex in mesh.data.vertices:
        print(vertex.select)
        if vertex.select:
            selected.append(vertex)

    return selected

def align_bone_roll_to_vector(bone, head_pos, tail_pos, vector):
    """
    Align bone roll so its Z axis matches the given normal.
    """

    direction = (tail_pos - head_pos).normalized()
    vector = vector.normalized()

    # Avoid degenerate case (normal parallel to direction)
    if abs(direction.dot(vector)) > 0.999:
        return

    # X = Y × Z
    x_axis = direction.cross(vector).normalized()
    z_axis = x_axis.cross(direction).normalized()

    # Bone local axes: X, Y, Z
    rot_matrix = Matrix((
        x_axis,
        direction,
        z_axis,
    )).transposed()

    bone.matrix = Matrix.Translation(head_pos) @ rot_matrix.to_4x4()


def align_curve_tilt_to_vector(tangent, normal):
    """
    Calculate the tilt angle required to align a curve point's normal (local Z)
    to the given normal vector. Returns tilt in radians.
    """
    tangent = tangent.normalized()
    normal = normal.normalized()

    # Avoid degenerate case (normal parallel to tangent)
    if abs(tangent.dot(normal)) > 0.999:
        return 0.0

    # Calculate target rotation frame
    # We assume Tangent = Local Y, Normal = Local Z
    # Local X = Y x Z
    x_axis = tangent.cross(normal).normalized()
    z_axis = x_axis.cross(tangent).normalized()

    target_quat = Matrix((
        x_axis,
        tangent,
        z_axis
    )).transposed().to_quaternion()

    # Reference frame (Z-Up)
    ref_quat = tangent.to_track_quat('Y', 'Z')

    # Calculate tilt correction
    tilt_rot = ref_quat.inverted() @ target_quat
    return tilt_rot.to_euler().y
    

def ensure_armature(context, armature_name = "Armature") -> Object:
        print(type(context))
        """Return existing armature or create a new one"""
        for obj in context.selected_objects:
            if obj.type == "ARMATURE":
                return obj

        new_armature = add_armature(armature_name, context)
        return new_armature

def find_mesh(context) -> Optional[Object]:
        """Return the first selected mesh"""
        for obj in context.selected_objects:
            if obj.type == "MESH":
                return obj
        return None
    
def find_curve(context) -> Optional[Object]:
        """Return the first selected curve"""
        for obj in context.selected_objects:
            if obj.type == "CURVE":
                return obj
        return None

def local_to_world_vertices(mesh) -> list:
    world_space_vertices = []
    for vertex in mesh.data.vertices:
        world_space_vertices.append(mesh.matrix_world @ vertex.co)

    return world_space_vertices
