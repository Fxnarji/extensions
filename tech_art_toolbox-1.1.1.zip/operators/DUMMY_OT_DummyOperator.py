import bpy  # type: ignore
from ..helper import get_operator


class DUMMY_OT_DummyOperator(bpy.types.Operator):
    bl_idname = get_operator("dummy")
    bl_label = "Dummy Operator"
    bl_options = {'REGISTER', 'UNDO'}

    string_prop: bpy.props.StringProperty(
        default="AString!"
        ) #type:ignore
        

    enum_items=[
        ('value1', "Name1", "Descripton1"), 
        ]
    enum_props: bpy.props.EnumProperty(
        items=enum_items
        )#type: ignore
    

    # ---------------------------------------------------------------------
    # Poll
    # ---------------------------------------------------------------------

    @classmethod
    def poll(cls, context):
        return None

    # ---------------------------------------------------------------------
    # Execute
    # ---------------------------------------------------------------------

    def execute(self, context):
        return {"FINISHED"}

    # ---------------------------------------------------------------------
    # Internal Helpers
    # ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------