import bpy      # type: ignore
import bmesh    # type: ignore

from bpy.types import EditBone          # type: ignore
from typing import List, Optional, Dict # type: ignore
from mathutils import Vector            # type: ignore
from bpy.types import Object            # type: ignore
from bmesh.types import BMVert          # type: ignore


# has two entries: "normal", "pos"
VertexPathItem = Dict[str, Vector]

from ..helper import (
    get_operator,
    ensure_armature,
    get_selected_vertices_from_mesh,
    align_bone_roll_to_vector,
    find_mesh
)


class OBJECT_OT_SpawnBonesOnVertexPath(bpy.types.Operator):
    """Create a connected bone chain following a vertex path"""

    bl_idname = get_operator("spawn_bones_on_vertex_path")
    bl_label = "Spawn Bones From Vertex Path"
    bl_options = {'REGISTER', 'UNDO'}

    #region Properties
    reverse: bpy.props.BoolProperty(
        name="Reverse Chain",
        description="Reverse bone direction",
        default=False,
    )  # type: ignore

    mark_deform: bpy.props.BoolProperty(
        name="Mark Deform",
        description="Marks Generated Bones as Deform Bones",
        default=False,
    )  # type: ignore

    bone_name: bpy.props.StringProperty(
        name="Bone Name",
        default="Bone",
    )  # type: ignore

    offset: bpy.props.FloatProperty(
        name="Offset",
        default=0,
    )  # type: ignore

    bone_roll: bpy.props.FloatProperty(
        name="Bone Roll",
        default=0,
    )  # type: ignore

    armature_name: bpy.props.StringProperty(
        name="Armature Name",
        default="Armature",
    )  # type: ignore
#endregion

    # ---------------------------------------------------------------------
    # Poll
    # ---------------------------------------------------------------------

    @classmethod
    def poll(cls, context):
        """Operator is valid if at least one mesh is selected"""
        return any(obj.type == "MESH" for obj in context.selected_objects)

    # ---------------------------------------------------------------------
    # Execute
    # ---------------------------------------------------------------------

    def execute(self, context):

        # Ensure an armature exists (create one if needed)
        armature_obj = ensure_armature(context=context, armature_name=self.armature_name)
        
        # Resolve mesh + armature pairing
        mesh_obj = find_mesh(context)
        if not mesh_obj:
            return {'CANCELLED'}

        # Decide whether to use only selected vertices
        use_selected_only = self._use_selected_vertices(mesh_obj)

        # Compute vertex path (mesh edit mode)
        vertex_path = self._calculate_vertex_path(mesh_obj, use_selected_only)
        if not vertex_path:
            return {'CANCELLED'}

        # transform path into armature space
        vertex_path = self._convert_vertex_path_to_armature_space(
            vertex_path,
            mesh_obj,
            armature_obj
        )

        if self.reverse:
            vertex_path.reverse()

        # Build bones (armature edit mode)
        self._create_bone_chain(armature_obj, vertex_path)

        return {'FINISHED'}

    # ---------------------------------------------------------------------
    # Internal helpers
    # ---------------------------------------------------------------------



    def _convert_vertex_path_to_armature_space(
        self,
        vertex_path: List[VertexPathItem],
        mesh_obj: Object,
        armature_obj: Object
    ) -> List[VertexPathItem]:

        mesh_mw = mesh_obj.matrix_world
        arm_inv = armature_obj.matrix_world.inverted()

        mesh_rot = mesh_mw.to_3x3()
        arm_rot_inv = arm_inv.to_3x3()

        converted = []

        for item in vertex_path:
            world_pos = mesh_mw @ item["pos"]
            arm_pos = arm_inv @ world_pos

            world_normal = (mesh_rot @ item["normal"]).normalized()
            arm_normal = (arm_rot_inv @ world_normal).normalized()

            converted.append({
                "pos": arm_pos,
                "normal": arm_normal,
            })

        return converted

    def _use_selected_vertices(self, mesh_obj: Object) -> bool:
        """
        We only restrict to selected vertices if the selection
        is meaningful (2+ vertices).
        """
        selected = get_selected_vertices_from_mesh(mesh_obj)
        return len(selected) >= 2

    def _calculate_vertex_path(self, mesh_obj: Object, selected_only:bool) -> Optional[List[VertexPathItem]]:
        """Enter edit mode, validate topology, and extract vertex chain"""

        previous_mode = mesh_obj.mode
        context = bpy.context

        context.view_layer.objects.active = mesh_obj
        bpy.ops.object.mode_set(mode='EDIT')

        try:
            return calculate_vertex_chain(mesh_obj, selected_only)
        finally:
            bpy.ops.object.mode_set(mode=previous_mode)

    def _create_bone_chain(self, armature_obj: Object, vertex_path: list[VertexPathItem]) -> List[EditBone]:
        """Create connected bones following the given vertex positions"""

        armature = armature_obj.data
        context = bpy.context

        previous_mode = armature_obj.mode
        context.view_layer.objects.active = armature_obj
        bpy.ops.object.mode_set(mode='EDIT')

        bone_chain = []

        try:
            previous_bone = None

            for head, tail in zip(vertex_path, vertex_path[1:]):
                bone = armature.edit_bones.new(self.bone_name)
                bone.head = head["pos"] + head["normal"] * self.offset
                bone.tail = tail["pos"]+ tail["normal"] * self.offset
                
                align_bone_roll_to_vector(bone, bone.head, bone.tail, head["normal"])

                bone.roll += self.bone_roll

                # mark as DEF if neccessary
                if self.mark_deform:
                    bone.use_deform = True
                    bone.name = "DEF_" + bone.name
                else:
                    bone.use_deform = False

                bone_chain.append(bone)

                if previous_bone:
                    bone.parent = previous_bone
                    bone.use_connect = True


                previous_bone = bone

        finally:
            bpy.ops.object.mode_set(mode=previous_mode)
        return bone_chain


# ---------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------


def calculate_vertex_chain(mesh_obj: Object, selected_only=False) -> List[VertexPathItem]:
    """
    Return a list of vertex coordinates representing a linear chain.
    Returns None if topology is invalid.
    """

    bm = bmesh.from_edit_mesh(mesh_obj.data)

    vertices = (
        [v for v in bm.verts if v.select]
        if selected_only
        else list(bm.verts)
    )

    if not is_valid_vertex_chain(vertices):
        return None

    start_vertex = get_chain_endpoint(vertices)
    if not start_vertex:
        return None

    positions = walk_vertex_chain(start_vertex, vertices)

    bmesh.update_edit_mesh(mesh_obj.data)
    bpy.ops.object.mode_set(mode='OBJECT')

    return positions

def is_valid_vertex_chain(bm_vertices: List[BMVert]) -> bool:
    """
    Valid chain rules:
    - At least 2 vertices
    - Exactly 2 endpoints (degree == 1)
    - No branching (degree > 2)
    """

    if len(bm_vertices) < 2:
        return False

    endpoint_count = 0

    for v in bm_vertices:
        neighbors = get_connected_vertices(v, bm_vertices)

        if len(neighbors) == 1:
            endpoint_count += 1
        elif len(neighbors) > 2:
            return False  # branching detected

    return endpoint_count == 2

def get_chain_endpoint(bm_vertices: List[BMVert]) -> Optional[BMVert]:
    """Return a vertex with exactly one neighbor (an endpoint)"""

    for v in bm_vertices:
        if len(get_connected_vertices(v, bm_vertices)) == 1:
            return v
    return None

def walk_vertex_chain(start_vertex: BMVert, bm_vertices: List[BMVert], previous: Optional[BMVert] = None, positions: Optional[List[VertexPathItem]]=None) -> List[VertexPathItem]:
    """
    Depth-first walk along the chain, staying inside the vertex set.
    Returns a list of dicts: { "pos": Vector, "normal": Vector }
    """

    if positions is None:
        positions = []

    positions.append({
        "pos": start_vertex.co.copy(),
        "normal": start_vertex.normal.copy()
    })

    for neighbor in get_connected_vertices(start_vertex, bm_vertices):
        if neighbor != previous:
            return walk_vertex_chain(
                neighbor,
                bm_vertices,
                start_vertex,
                positions
            )

    return positions

def get_connected_vertices(vertex: BMVert, vertex_pool: List[BMVert]) -> List[BMVert]:
    """Return neighbors of `vertex` that are inside `vertex_pool`"""

    return [
        e.other_vert(vertex)
        for e in vertex.link_edges
        if e.other_vert(vertex) in vertex_pool
    ]
