import bpy  # type: ignore
from ..helper import get_operator


class OBJECT_OT_HardsurfaceModifierSetup(bpy.types.Operator):
    bl_idname = get_operator("hardsurface_setup")
    bl_label = "Hardsurface Setup"
    bl_options = {'REGISTER', 'UNDO'}
    

    # ---------------------------------------------------------------------
    # Poll
    # ---------------------------------------------------------------------

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) >= 1

    # ---------------------------------------------------------------------
    # Execute
    # ---------------------------------------------------------------------

    def execute(self, context):

        for obj in context.selected_objects:
            modifier = obj.modifiers.new(name = "Bevel",type = 'BEVEL')
            modifier.segments = 2
            modifier.profile = 1
            modifier.limit_method = 'WEIGHT'


        return {"FINISHED"}

    # ---------------------------------------------------------------------
    # Internal Helpers
    # ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------