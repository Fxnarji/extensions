import bpy  # type: ignore
from ..helper import get_operator


class ARMATURE_OT_ClearBoneProperties(bpy.types.Operator):
    bl_idname = get_operator("clear_bone_properties")
    bl_label = "Clear Bone Properties"
    bl_options = {'REGISTER', 'UNDO'}

    selected_only: bpy.props.BoolProperty(
        name="Selected only",
        description="Clear selected Bones only",
        default=True,
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        return context.active_object.type == "ARMATURE" if context.active_object else False

    def execute(self, context):
        armature = context.active_object
        
        # get edit bones
        bones = []
        if armature.mode == "EDIT":
            for bone in armature.data.edit_bones:
                if bone.select or not self.selected_only:
                    bones.append(bone)


        # get pose bones
        if armature.mode == "POSE" or armature.mode == "OBJECT":
            for bone in armature.pose.bones:
                if bone.select or not self.selected_only:
                    bones.append(bone)



        # remove bone properties
        for bone in bones:
            for key in list(bone.keys()):
                if key not in "_RNA_UI":  # always keep Blender UI metadata
                    print(f"remove {key} from {bone}")
                    del bone[key]


        
        return {"FINISHED"}

