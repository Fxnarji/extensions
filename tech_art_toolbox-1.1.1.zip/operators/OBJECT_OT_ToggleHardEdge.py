import bpy  # type: ignore
from ..helper import get_operator


class OBJECT_OT_ToggleHardEdge(bpy.types.Operator):
    bl_idname = get_operator("toggle_sharp")
    bl_label = "Toggle Sharp Edge"
    bl_options = {'REGISTER', 'UNDO'}
    

    domain=[
        ('edges', "edges", ""), 
        ('vertex', "vertex", ""), 
        ]
    domain_props: bpy.props.EnumProperty(
        items=domain
        )#type: ignore

    value: bpy.props.FloatProperty(
    default= 0.0
    ) #type:ignore
    
    
    mode=[
        ('crease', "crease", ""), 
        ('bevel_weight', "bevel", ""), 
        ]
    mode_props: bpy.props.EnumProperty(
        items=mode
        )#type: ignore
    


    # ---------------------------------------------------------------------
    # Poll
    # ---------------------------------------------------------------------

    @classmethod
    def poll(cls, context):
        if not context.active_object:
            return False
        
        if not context.active_object.type == "MESH":
            return False
            
        return True

    # ---------------------------------------------------------------------
    # Execute
    # ---------------------------------------------------------------------

    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')
        
        self.obj = context.active_object

        if self.domain_props == "edges":
            self.mark_edges()
        if self.domain_props == "vertex":
            self.mark_vertices()

        bpy.ops.object.mode_set(mode='EDIT')

        return {"FINISHED"}

    # ---------------------------------------------------------------------
    # Internal Helpers
    # ---------------------------------------------------------------------

    def mark_vertices(self):
        mesh = self.obj.data
        print(mesh.name)

        mesh.vertex_creases_ensure()

        if "bevel_weight_vert" not in mesh.attributes:
            mesh.attributes.new(name="bevel_weight_vert", type='FLOAT', domain='POINT')

        attr = mesh.attributes[f"{self.mode_props}_vert"]
        data = attr.data

        for i, vert in enumerate(mesh.vertices):
            print(vert)
            if vert.select:
                data[i].value = self.value



    def mark_edges(self):
        mesh = self.obj.data

        # ensure creases
        mesh.edge_creases_ensure()

        # ensure bevel
        if "bevel_weight_edge" not in mesh.attributes:
            mesh.attributes.new(name="bevel_weight_edge", type='FLOAT', domain='EDGE')

        attr = mesh.attributes[f"{self.mode_props}_edge"]
        data = attr.data

        for i, edge in enumerate(mesh.edges):
            if edge.select:
                data[i].value = self.value
# ---------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------