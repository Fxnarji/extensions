import bpy  # type: ignore
from ..helper import get_operator, flip_bone, ensure_armature, find_mesh, align_bone_roll_to_vector
from mathutils import Vector # type: ignore
# Define the operator to snap FK bones to IK bones

vector_dict = {
    "x": Vector([1,0,0]),
    "y": Vector([0,1,0]),
    "z": Vector([0,0,1]),
}

class OBJECT_OT_CreateBonesOnDomain(bpy.types.Operator):
    bl_idname = get_operator("create_bones_on_domain")
    bl_label = "Create Bones on domain"
    bl_options = {'REGISTER', 'UNDO'}

    cursor_pos = None

    bone_name: bpy.props.StringProperty(
        default="Bone"
        ) #type:ignore
    
    armature_name: bpy.props.StringProperty(
        default="Armature"
        ) #type:ignore

    domains=[
        ('polygons', "Faces", ""), 
        ('vertices', "Vertices", ""),
        ('edges', "Edges", ""),
        ]
    domain: bpy.props.EnumProperty(
        items=domains
        )#type: ignore
    
    directions=[
        ('normal', "Normal", ""), 
        ('x', "X", ""),
        ('y', "Y", ""),
        ('z', "Z", ""),
        ('cursor', "3D cursor", "")
        ]
    direction: bpy.props.EnumProperty(
        items=directions,
        default = "normal"
        )#type: ignore
    
    flip: bpy.props.BoolProperty()#type: ignore
    

    # ---------------------------------------------------------------------
    # Poll
    # ---------------------------------------------------------------------


    @classmethod
    def poll(cls, context):
        enough_objects = len(context.selected_objects) >= 1

        has_mesh = False
        for obj in context.selected_objects:
            if obj.type == "MESH":
                has_mesh = True

        return enough_objects and has_mesh

    # ---------------------------------------------------------------------
    # Execute
    # --------------------------------------------------------------------- 
    def execute(self, context):
        self.cursor_pos = context.scene.cursor.location

        armature_obj = ensure_armature(context, self.armature_name)
        mesh_obj = find_mesh(context)
        armature = armature_obj.data

        context.view_layer.objects.active = armature_obj
        mode_before = armature_obj.mode
        bpy.ops.object.mode_set(mode='EDIT')
        

        if self.domain == "polygons":
            self.create_on_faces(mesh_obj, armature_obj, armature)

        if self.domain == "edges":
            self.create_on_edge_center(mesh_obj, armature_obj, armature)
        
        elif self.domain == "vertices":
            self.create_on_vertices(mesh_obj, armature_obj, armature)

 
   
        bpy.ops.object.mode_set(mode=mode_before)
        return {'FINISHED'}
    
    # ---------------------------------------------------------------------
    # Internal Helper
    # --------------------------------------------------------------------- 

    def create_on_edge_center(self, mesh_obj, armature_obj, armature):
        mesh_mw = mesh_obj.matrix_world
        arm_inv = armature_obj.matrix_world.inverted()

        vertices = mesh_obj.data.vertices

        for edge in mesh_obj.data.edges:


            # calculatin position
            combined_pos = Vector([0,0,0])
            for vertex_idx in edge.vertices:
                combined_pos += vertices[vertex_idx].co
            average_pos = combined_pos / 2

            # calculating normal
            normal = Vector([0,0,0])
            for vertex_idx in edge.vertices:
                normal += vertices[vertex_idx].normal

            if normal.length > 0:
                normal.normalize()


            # setting head
            world_pos = mesh_mw @ average_pos
            new_bone = armature.edit_bones.new(self.bone_name)
            new_bone.head = arm_inv @ world_pos

            # setting tail manually because we dont have a domain_inst with normal and position
            if self.direction == "normal":
                # normal → world (rotation only!)
                normal_world = (mesh_mw.to_3x3() @ normal).normalized()
                new_bone.tail = new_bone.head + (arm_inv.to_3x3() @ normal_world)

            elif self.direction in vector_dict:
                new_bone.tail = new_bone.head + vector_dict[self.direction]

            elif self.direction == "cursor":
                new_bone.tail = arm_inv @ self.cursor_pos

            

        return

    def create_on_faces(self, mesh_obj, armature_obj, armature):
        mesh_mw = mesh_obj.matrix_world
        arm_inv = armature_obj.matrix_world.inverted()

        for polygon in mesh_obj.data.polygons:
            bone = armature.edit_bones.new(self.bone_name)

            # Face center (world → armature local)
            world_center = mesh_mw @ polygon.center
            bone.head = arm_inv @ world_center

            self.set_bone_tail(bone, polygon, mesh_obj, armature_obj)


    def create_on_vertices(self, mesh_obj, armature_obj, armature):
        mesh_mw = mesh_obj.matrix_world
        arm_inv = armature_obj.matrix_world.inverted()

        for vertex in mesh_obj.data.vertices:
            bone = armature.edit_bones.new(self.bone_name)

            # Vertex position (world → armature local)
            world_pos = mesh_mw @ vertex.co
            bone.head = arm_inv @ world_pos

            self.set_bone_tail(bone, vertex, mesh_obj, armature_obj)


    def set_bone_tail(self, bone, domain_inst, mesh_obj, armature_obj):
        mesh_mw = mesh_obj.matrix_world
        arm_inv = armature_obj.matrix_world.inverted()

        if self.direction == "normal":
            # normal → world (rotation only!)
            normal_world = (mesh_mw.to_3x3() @ domain_inst.normal).normalized()
            bone.tail = bone.head + (arm_inv.to_3x3() @ normal_world)

        elif self.direction in vector_dict:
            bone.tail = bone.head + vector_dict[self.direction]

        elif self.direction == "cursor":
            bone.tail = arm_inv @ self.cursor_pos

        if self.flip:
            flip_bone(bone)

        # align bone after flipping to avoid issues
        if self.direction == "normal":
            align_bone_roll_to_vector(bone, bone.head, bone.tail, normal_world)


# ---------------------------------------------------------------------
# Util
# --------------------------------------------------------------------- 

def place_debug_empty(pos):
    bpy.ops.object.empty_add(type='ARROWS', radius=1, align='WORLD', location=pos, scale=(1, 1, 1))



