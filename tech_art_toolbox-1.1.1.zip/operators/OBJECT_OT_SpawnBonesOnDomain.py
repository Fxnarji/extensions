import bpy  # type: ignore
from ..helper import get_operator, flip_bone, ensure_armature, find_mesh, align_bone_roll_to_vector
from mathutils import Vector
# Define the operator to snap FK bones to IK bones

vector_dict = {
    "x": Vector([1,0,0]),
    "y": Vector([0,1,0]),
    "z": Vector([0,0,1]),
}

class OBJECT_OT_SpawnBonesOnDomain(bpy.types.Operator):
    bl_idname = get_operator("spawn_bones_on_domain")
    bl_label = "Spawns Bones on domain"
    bl_options = {'REGISTER', 'UNDO'}

    cursor_pos = None

    bone_name: bpy.props.StringProperty(
        default="Bone"
        ) #type:ignore
    
    armature_name: bpy.props.StringProperty(
        default="Armature"
        ) #type:ignore

    domains=[
        ('polygons', "Faces", ""), 
        ('vertices', "Vertices", "")
        ]
    domain: bpy.props.EnumProperty(
        items=domains
        )#type: ignore
    
    directions=[
        ('normal', "Normal", ""), 
        ('x', "X", ""),
        ('y', "Y", ""),
        ('z', "Z", ""),
        ('cursor', "3D cursor", "")
        ]
    direction: bpy.props.EnumProperty(
        items=directions,
        default = "normal"
        )#type: ignore
    
    flip: bpy.props.BoolProperty()#type: ignore
    

    # ---------------------------------------------------------------------
    # Poll
    # ---------------------------------------------------------------------


    @classmethod
    def poll(cls, context):
        enough_objects = len(context.selected_objects) >= 1

        has_mesh = False
        for obj in context.selected_objects:
            if obj.type == "MESH":
                has_mesh = True

        return enough_objects and has_mesh

    # ---------------------------------------------------------------------
    # Execute
    # --------------------------------------------------------------------- 
    def execute(self, context):
        
        self.cursor_pos = context.scene.cursor.location

        armature_obj = ensure_armature(context, self.armature_name)
        mesh_obj = find_mesh(context)
        armature = armature_obj.data

        context.view_layer.objects.active = armature_obj
        mode_before = armature_obj.mode
        bpy.ops.object.mode_set(mode='EDIT')
        

        if self.domain == "polygons":
            self.spawn_on_faces(mesh_obj, armature_obj, armature)

        elif self.domain == "vertices":
            self.spawn_on_vertices(mesh_obj, armature_obj, armature)

 
   
        bpy.ops.object.mode_set(mode=mode_before)
        return {'FINISHED'}
    
    # ---------------------------------------------------------------------
    # Internal Helper
    # --------------------------------------------------------------------- 

    def spawn_on_faces(self, mesh_obj, armature_obj, armature):
        mesh_mw = mesh_obj.matrix_world
        arm_inv = armature_obj.matrix_world.inverted()

        for polygon in mesh_obj.data.polygons:
            bone = armature.edit_bones.new(self.bone_name)

            # Face center (world → armature local)
            world_center = mesh_mw @ polygon.center
            bone.tail = arm_inv @ world_center

            self.set_bone_head(bone, polygon, mesh_obj, armature_obj)


    def spawn_on_vertices(self, mesh_obj, armature_obj, armature):
        mesh_mw = mesh_obj.matrix_world
        arm_inv = armature_obj.matrix_world.inverted()

        for vertex in mesh_obj.data.vertices:
            bone = armature.edit_bones.new(self.bone_name)

            # Vertex position (world → armature local)
            world_pos = mesh_mw @ vertex.co
            bone.tail = arm_inv @ world_pos

            self.set_bone_head(bone, vertex, mesh_obj, armature_obj)


    def set_bone_head(self, bone, domain_inst, mesh_obj, armature_obj):
        mesh_mw = mesh_obj.matrix_world
        arm_inv = armature_obj.matrix_world.inverted()

        if self.direction == "normal":
            # normal → world (rotation only!)
            normal_world = (mesh_mw.to_3x3() @ domain_inst.normal).normalized()
            bone.head = bone.tail + (arm_inv.to_3x3() @ normal_world)

        elif self.direction in vector_dict:
            bone.head = bone.tail + vector_dict[self.direction]

        elif self.direction == "cursor":
            bone.head = arm_inv @ self.cursor_pos

        if self.flip:
            flip_bone(bone)

        # align bone after flipping to avoid issues
        if self.direction == "normal":
            align_bone_roll_to_vector(bone, bone.head, bone.tail, normal_world)


# ---------------------------------------------------------------------
# Util
# --------------------------------------------------------------------- 



