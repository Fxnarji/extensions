import bpy  # type: ignore
from ..helper import get_operator


class ARMATURE_OT_CopyPropertiesFromActiveBone(bpy.types.Operator):
    bl_idname = get_operator("dummy")
    bl_label = "Copy Custom Properties From Active Bone"
    bl_options = {'REGISTER', 'UNDO'}

    # ---------------------------------------------------------------------
    # Poll
    # ---------------------------------------------------------------------
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj or obj.type != "ARMATURE":
            return False

        if obj.mode == 'EDIT':
            return context.active_bone is not None
        else:
            return context.active_pose_bone is not None

    # ---------------------------------------------------------------------
    # Execute
    # ---------------------------------------------------------------------
    def execute(self, context):
        obj = context.active_object

        if obj.mode == 'EDIT':
            source = context.active_bone
            targets = context.selected_bones
        else:
            source = context.active_pose_bone
            targets = context.selected_pose_bones

        if not source:
            return {'CANCELLED'}

        # Collect custom properties (ignore _RNA_UI)
        custom_props = {
            key: source[key]
            for key in source.keys()
            if key != "_RNA_UI"
        }

        for bone in targets:
            if bone == source:
                continue

            # Copy properties
            for key, value in custom_props.items():
                bone[key] = value

            # Copy UI metadata if it exists
            if "_RNA_UI" in source:
                bone["_RNA_UI"] = source["_RNA_UI"].copy()

        return {'FINISHED'}
