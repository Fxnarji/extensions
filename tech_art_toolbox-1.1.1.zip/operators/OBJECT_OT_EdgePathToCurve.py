import bpy      # type: ignore
import bmesh    # type: ignore

from bpy.types import EditBone          # type: ignore
from typing import List, Optional, Dict # type: ignore
from mathutils import Vector            # type: ignore
from bpy.types import Object            # type: ignore
from bmesh.types import BMVert          # type: ignore


# has two entries: "normal", "pos"
VertexPathItem = Dict[str, Vector]

from ..helper import (
    get_operator,
    get_selected_vertices_from_mesh,
    find_mesh,
    align_curve_tilt_to_vector
)


class OBJECT_OT_EdgePathToCurve(bpy.types.Operator):
    """Create a connected bone chain following a vertex path"""

    bl_idname = get_operator("edge_path_to_curve")
    bl_label = "Creates a new Curve from selected Edges"
    bl_options = {'REGISTER', 'UNDO'}

    #region Properties
    reverse: bpy.props.BoolProperty(
        name="Reverse Chain",
        description="Reverse bone direction",
        default=False,
    )  # type: ignore

    mark_cyclic: bpy.props.BoolProperty(
        name="Cyclic",
        description="Set Curve as open or closed.",
        default=False,
    )  # type: ignore

    curve_name: bpy.props.StringProperty(
        name="Curve Name",
        default="Curve_from_EdgePath",
    )  # type: ignore

    offset: bpy.props.FloatProperty(
        name="Offset",
        default=0,
    )  # type: ignore

    tilt: bpy.props.FloatProperty(
        name="Tilt",
        default=0,
        subtype='ANGLE',
        unit='ROTATION'
    )  # type: ignore

#endregion

    # ---------------------------------------------------------------------
    # Poll
    # ---------------------------------------------------------------------

    @classmethod
    def poll(cls, context):
        """Operator is valid if at least one mesh is selected"""
        # Allow polling if a Curve is active (likely the result of this operator during Redo)
        if context.active_object and context.active_object.type == 'CURVE':
            return True
        return any(obj.type == "MESH" for obj in context.selected_objects)

    # ---------------------------------------------------------------------
    # Execute
    # ---------------------------------------------------------------------

    def execute(self, context):

        # get mesh
        mesh_obj = find_mesh(context)
        if not mesh_obj:
            return {'CANCELLED'}

        # Decide whether to use only selected vertices
        use_selected_only = self._use_selected_vertices(mesh_obj)

        # Compute vertex path (mesh edit mode)
        vertex_path = self._calculate_vertex_path(mesh_obj, use_selected_only)
        if not vertex_path:
            return {'CANCELLED'}

        if self.reverse:
            vertex_path.reverse()
            
        self._create_curve_spline(mesh_obj, vertex_path)

        return {'FINISHED'}

    # ---------------------------------------------------------------------
    # Internal helpers
    # ---------------------------------------------------------------------


    def _use_selected_vertices(self, mesh_obj: Object) -> bool:
        """
        We only restrict to selected vertices if the selection
        is meaningful (2+ vertices).
        """
        selected = get_selected_vertices_from_mesh(mesh_obj)
        return len(selected) >= 2

    def _calculate_vertex_path(self, mesh_obj: Object, selected_only:bool) -> Optional[List[VertexPathItem]]:
        """Enter edit mode, validate topology, and extract vertex chain"""

        previous_mode = mesh_obj.mode
        context = bpy.context

        context.view_layer.objects.active = mesh_obj
        bpy.ops.object.mode_set(mode='EDIT')

        try:
            return calculate_vertex_chain(mesh_obj, selected_only)
        finally:
            bpy.ops.object.mode_set(mode=previous_mode)

    def _create_curve_spline(self, mesh_obj: Object, vertex_path: list[VertexPathItem]):
        """Create a new curve object from the vertex path"""
        
        # Create curve data and object
        curve_data = bpy.data.curves.new(name=self.curve_name, type='CURVE')
        curve_data.dimensions = '3D'
        
        curve_obj = bpy.data.objects.new(self.curve_name, curve_data)
        bpy.context.collection.objects.link(curve_obj)
        
        # Create spline
        spline = curve_data.splines.new(type='POLY')
        
        # Allocate points (one point already exists)
        spline.points.add(len(vertex_path) - 1)
        
        mesh_world_matrix = mesh_obj.matrix_world
        mesh_world_matrix_rotation = mesh_world_matrix.to_3x3()
        
        # Set point data
        for i, item in enumerate(vertex_path):
            point = spline.points[i]
            
            # Convert to world space
            normal = (mesh_world_matrix_rotation @ item["normal"]).normalized()
            pos = mesh_world_matrix @ item["pos"]
            
            # Apply offset
            pos = pos + (normal * self.offset)
            
            # Set position (w=1.0 for weight)
            point.co = (pos.x, pos.y, pos.z, 1.0)
            
            # Calculate tangent for tilt alignment
            if i < len(vertex_path) - 1:
                # Use direction to next point
                next_pos_local = vertex_path[i+1]["pos"]
                next_normal_local = vertex_path[i+1]["normal"]
                
                next_normal = (mesh_world_matrix_rotation @ next_normal_local).normalized()
                next_pos = (mesh_world_matrix @ next_pos_local) + (next_normal * self.offset)
                
                tangent = next_pos - pos
            elif i > 0:
                # Use direction from prev point
                prev_pos_local = vertex_path[i-1]["pos"]
                prev_normal_local = vertex_path[i-1]["normal"]
                
                prev_normal = (mesh_world_matrix_rotation @ prev_normal_local).normalized()
                prev_pos = (mesh_world_matrix @ prev_pos_local) + (prev_normal * self.offset)
                
                tangent = pos - prev_pos
            else:
                tangent = Vector((0, 0, 1))
            
            # Apply tilt
            point.tilt = align_curve_tilt_to_vector(tangent, normal) + self.tilt
            
        # Set cyclic
        spline.use_cyclic_u = self.mark_cyclic
        
        # Select the new curve
        bpy.ops.object.mode_set(mode='OBJECT')
        mesh_obj.select_set(False) 
        curve_obj.select_set(True)
        bpy.context.view_layer.objects.active = curve_obj
        
        return curve_obj


# ---------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------


def calculate_vertex_chain(mesh_obj: Object, selected_only=False) -> List[VertexPathItem]:
    """
    Return a list of vertex coordinates representing a linear chain.
    Returns None if topology is invalid.
    """

    bm = bmesh.from_edit_mesh(mesh_obj.data)

    vertices = (
        [v for v in bm.verts if v.select]
        if selected_only
        else list(bm.verts)
    )

    if not is_valid_vertex_chain(vertices):
        return None

    start_vertex = get_chain_endpoint(vertices)
    if not start_vertex:
        return None

    positions = walk_vertex_chain(start_vertex, vertices)

    bmesh.update_edit_mesh(mesh_obj.data)
    bpy.ops.object.mode_set(mode='OBJECT')

    return positions

def is_valid_vertex_chain(bm_vertices: List[BMVert]) -> bool:
    """
    Valid chain rules:
    - At least 2 vertices
    - Exactly 2 endpoints (degree == 1)
    - No branching (degree > 2)
    """

    if len(bm_vertices) < 2:
        return False

    endpoint_count = 0

    for v in bm_vertices:
        neighbors = get_connected_vertices(v, bm_vertices)

        if len(neighbors) == 1:
            endpoint_count += 1
        elif len(neighbors) > 2:
            return False  # branching detected

    return endpoint_count == 2

def get_chain_endpoint(bm_vertices: List[BMVert]) -> Optional[BMVert]:
    """Return a vertex with exactly one neighbor (an endpoint)"""

    for v in bm_vertices:
        if len(get_connected_vertices(v, bm_vertices)) == 1:
            return v
    return None

def walk_vertex_chain(start_vertex: BMVert, bm_vertices: List[BMVert], previous: Optional[BMVert] = None, positions: Optional[List[VertexPathItem]]=None) -> List[VertexPathItem]:
    """
    Depth-first walk along the chain, staying inside the vertex set.
    Returns a list of dicts: { "pos": Vector, "normal": Vector }
    """

    if positions is None:
        positions = []

    positions.append({
        "pos": start_vertex.co.copy(),
        "normal": start_vertex.normal.copy()
    })

    for neighbor in get_connected_vertices(start_vertex, bm_vertices):
        if neighbor != previous:
            return walk_vertex_chain(
                neighbor,
                bm_vertices,
                start_vertex,
                positions
            )

    return positions

def get_connected_vertices(vertex: BMVert, vertex_pool: List[BMVert]) -> List[BMVert]:
    """Return neighbors of `vertex` that are inside `vertex_pool`"""

    return [
        e.other_vert(vertex)
        for e in vertex.link_edges
        if e.other_vert(vertex) in vertex_pool
    ]
