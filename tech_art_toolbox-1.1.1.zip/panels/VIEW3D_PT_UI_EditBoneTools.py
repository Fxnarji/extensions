import bpy  # type: ignore
from ..helper import AddonProperties
from ..operators.ARMATURE_OT_ClearBoneProperties import ARMATURE_OT_ClearBoneProperties
from ..operators.ARMATURE_OT_CopyPropertiesFromActiveBone import ARMATURE_OT_CopyPropertiesFromActiveBone


class VIEW3D_PT_UI_EditBoneTools(bpy.types.Panel):
    bl_label = "Edit Bone"
    bl_parent_id = "MAIN_PT_UI_RIGGING"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.0
        
        
        layout.operator(
            ARMATURE_OT_ClearBoneProperties.bl_idname,
            text = "Delete Bone Properties",
            icon = "TRASH")
        
        layout.operator(
            ARMATURE_OT_CopyPropertiesFromActiveBone.bl_idname,
            text = "Copy Properties from Active",
            icon = "COPYDOWN")