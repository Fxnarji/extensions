import bpy  # type: ignore
from ..helper import AddonProperties
from ..operators.OBJECT_OT_EdgePathToCurve import OBJECT_OT_EdgePathToCurve

class VIEW3D_PT_UI_Curves(bpy.types.Panel):
    bl_label = "Curves"
    bl_parent_id = "MAIN_PT_UI_RIGGING"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.0

        # edge path to curve

        layout.operator(
            OBJECT_OT_EdgePathToCurve.bl_idname, 
            text="Edge Path to Curve", 
            icon = "PARTICLE_PATH")
 

        




