import bpy  # type: ignore
from ..helper import AddonProperties
from ..operators.OBJECT_OT_SpawnBonesOnVertexPath import OBJECT_OT_SpawnBonesOnVertexPath
from ..operators.OBJECT_OT_SpawnBonesOnDomain import OBJECT_OT_SpawnBonesOnDomain

class VIEW3D_PT_UI_SpawnBoneTools(bpy.types.Panel):
    bl_label = "Spawn Bone Tools"
    bl_parent_id = "Main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.25
        

        # bones on mesh

        layout.operator(
            OBJECT_OT_SpawnBonesOnVertexPath.bl_idname, 
            text="Bones on Edge Path", 
            icon = "IPO_LINEAR")
        
        faces = layout.operator(
            OBJECT_OT_SpawnBonesOnDomain.bl_idname, 
            text="Bones on Faces", 
            icon = "FACESEL")
        faces.domain = "polygons"
        faces.direction = "normal"
        
        vertices = layout.operator(
            OBJECT_OT_SpawnBonesOnDomain.bl_idname, 
            text="Bones on Vertices", 
            icon = "VERTEXSEL")
        vertices.domain = "vertices"
        vertices.direction = "normal"
        




