import bpy  # type: ignore
from ..helper import AddonProperties
from ..operators.OBJECT_OT_CreateBonesOnMeshPath import OBJECT_OT_CreateBonesOnMeshPath
from ..operators.OBJECT_OT_CreateBonesOnDomain import OBJECT_OT_CreateBonesOnDomain

class VIEW3D_PT_UI_CreateBoneTools(bpy.types.Panel):
    bl_label = "Create Bone Tools"
    bl_parent_id = "Main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.0

        # bones on mesh

        vertices = layout.operator(
            OBJECT_OT_CreateBonesOnDomain.bl_idname, 
            text="Vertices", 
            icon = "VERTEXSEL")
        vertices.domain = "vertices"
        vertices.direction = "normal"

        edges = layout.operator(
            OBJECT_OT_CreateBonesOnDomain.bl_idname, 
            text="Edges", 
            icon = "EDGESEL")
        edges.domain = "edges"
        edges.direction = "normal"
        
        faces = layout.operator(
            OBJECT_OT_CreateBonesOnDomain.bl_idname, 
            text="Faces", 
            icon = "FACESEL")
        faces.domain = "polygons"
        faces.direction = "normal"
        
        layout.separator()
        
        layout.operator(
            OBJECT_OT_CreateBonesOnMeshPath.bl_idname, 
            text="Edge Path", 
            icon = "CURVE_PATH")
        
        layout.operator(
            OBJECT_OT_CreateBonesOnMeshPath.bl_idname, 
            text="Edge Center", 
            icon = "SNAP_MIDPOINT")
        

        




