import bpy  # type: ignore
from ..helper import AddonProperties
from ..operators.OBJECT_OT_CreateBonesOnMeshPath import OBJECT_OT_CreateBonesOnMeshPath
from ..operators.OBJECT_OT_CreateBonesOnDomain import OBJECT_OT_CreateBonesOnDomain

class VIEW3D_PT_UI_CreateBoneTools(bpy.types.Panel):
    bl_label = "Create Bone"
    bl_parent_id = "MAIN_PT_UI_RIGGING"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        layout = self.layout
        
        column = layout.column()
        
        column_domain = column.column()
        column.separator()
        column_path = column.column()
        
        grid_01 = column_domain.grid_flow(even_columns=True)
        grid_02 = column_path.grid_flow(even_columns=True)

        # bones on mesh

        vertices = grid_01.operator(
            OBJECT_OT_CreateBonesOnDomain.bl_idname, 
            text="Vertices", 
            icon = "VERTEXSEL")
        vertices.domain = "vertices"
        vertices.direction = "normal"

        edges = grid_01.operator(
            OBJECT_OT_CreateBonesOnDomain.bl_idname, 
            text="Edges", 
            icon = "EDGESEL")
        edges.domain = "edges"
        edges.direction = "normal"
        
        faces = grid_01.operator(
            OBJECT_OT_CreateBonesOnDomain.bl_idname, 
            text="Faces", 
            icon = "FACESEL")
        faces.domain = "polygons"
        faces.direction = "normal"
        

        
        grid_02.operator(
            OBJECT_OT_CreateBonesOnMeshPath.bl_idname, 
            text="Edge Path", 
            icon = "CURVE_PATH")
        
        grid_02.operator(
            OBJECT_OT_CreateBonesOnMeshPath.bl_idname, 
            text="Edge Center", 
            icon = "SNAP_MIDPOINT")
        

        




