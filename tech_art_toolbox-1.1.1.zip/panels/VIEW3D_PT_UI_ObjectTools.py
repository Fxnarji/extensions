import bpy  # type: ignore
from ..helper import AddonProperties

class VIEW3D_PT_UI_ObjectTools(bpy.types.Panel):
    bl_label = "Object Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_idname = "ObjectTools"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        return
