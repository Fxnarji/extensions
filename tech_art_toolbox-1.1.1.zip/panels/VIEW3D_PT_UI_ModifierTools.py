import bpy  # type: ignore
from ..helper import AddonProperties
from ..operators.OBJECT_OT_HardsurfaceModifierSetup import OBJECT_OT_HardsurfaceModifierSetup
from ..operators.OBJECT_OT_ToggleHardEdge import OBJECT_OT_ToggleHardEdge

class VIEW3D_PT_UI_ModifierTools(bpy.types.Panel):
    bl_label = "Modifier Tools"
    bl_parent_id = "ObjectTools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    def draw(self, context):
        layout = self.layout
        
        
        layout.operator(
            OBJECT_OT_HardsurfaceModifierSetup.bl_idname,
            text = "Add Hardsurface Modifiers",
            icon = "MOD_BEVEL")
        
#region edge
        edge_box = layout.box()
        edge_box.label(text = "Edges")

        edge_bevel_row = edge_box.row(align=True)

        edge_bevel = edge_bevel_row.operator(
            OBJECT_OT_ToggleHardEdge.bl_idname,
            text = "Set",
            icon = "EDGE_BEVEL")
        edge_bevel.domain_props = "edges"
        edge_bevel.mode_props = "bevel_weight"
        edge_bevel.value = 1.0


        edge_bevel = edge_bevel_row.operator(
            OBJECT_OT_ToggleHardEdge.bl_idname,
            text = "Clear",
            icon = "EDGESEL")
        edge_bevel.domain_props = "edges"
        edge_bevel.mode_props = "bevel_weight"
        edge_bevel.value = 0.0


        edge_crease_row = edge_box.row(align=True)

        edge_bevel = edge_crease_row.operator(
            OBJECT_OT_ToggleHardEdge.bl_idname,
            text = "Set",
            icon = "EDGE_CREASE")
        edge_bevel.domain_props = "edges"
        edge_bevel.mode_props = "crease"
        edge_bevel.value = 1.0


        edge_bevel = edge_crease_row.operator(
            OBJECT_OT_ToggleHardEdge.bl_idname,
            text = "Clear",
            icon = "EDGESEL")
        edge_bevel.domain_props = "edges"
        edge_bevel.mode_props = "crease"
        edge_bevel.value = 0.0
#endregion


#region vertex
        vertex_box = layout.box()
        vertex_box.label(text = "vertex")

        vertex_bevel_row = vertex_box.row(align=True)

        vertex_bevel = vertex_bevel_row.operator(
            OBJECT_OT_ToggleHardEdge.bl_idname,
            text = "Set",
            icon = "NODE_SOCKET_VECTOR")
        vertex_bevel.domain_props = "vertex"
        vertex_bevel.mode_props = "bevel_weight"
        vertex_bevel.value = 1.0


        vertex_bevel = vertex_bevel_row.operator(
            OBJECT_OT_ToggleHardEdge.bl_idname,
            text = "Clear",
            icon = "NODE_SOCKET_COLLECTION")
        vertex_bevel.domain_props = "vertex"
        vertex_bevel.mode_props = "bevel_weight"
        vertex_bevel.value = 0.0


        vertex_crease_row = vertex_box.row(align=True)

        vertex_bevel = vertex_crease_row.operator(
            OBJECT_OT_ToggleHardEdge.bl_idname,
            text = "Set",
            icon = "NODE_SOCKET_MATRIX")
        vertex_bevel.domain_props = "vertex"
        vertex_bevel.mode_props = "crease"
        vertex_bevel.value = 1.0


        vertex_bevel = vertex_crease_row.operator(
            OBJECT_OT_ToggleHardEdge.bl_idname,
            text = "Clear",
            icon = "NODE_SOCKET_COLLECTION")
        vertex_bevel.domain_props = "vertex"
        vertex_bevel.mode_props = "crease"
        vertex_bevel.value = 0.0
#endregion